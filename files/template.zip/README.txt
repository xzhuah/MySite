There are two templates in two different styles provided. They share structureMain.css file which is used to constrain the basic structure
of the webpage.Attributes like padding, margin, height,width are mainly defined in structureMain.css. Another two css files, appearMain1.css and appearMain2.css
are used to define color and background. You can copy and modify them to build various kinds of atmospheres for your webpages.



Designed by ZHU Xinyu.